import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JInternalFrame;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JTextPane;
import java.awt.Window.Type;

public class gui {

	private JFrame frmLoginScreen;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gui window = new gui();
					window.frmLoginScreen.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public gui() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLoginScreen = new JFrame();
		frmLoginScreen.setTitle("Login Screen");
		frmLoginScreen.setBounds(100, 100, 170, 260);
		frmLoginScreen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLoginScreen.getContentPane().setLayout(null);
		
		JButton btnTeacherLogin = new JButton("Teacher Login");
		btnTeacherLogin.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				TeacherScreen ts=new TeacherScreen();
				ts.TeacherScreen();
				frmLoginScreen.hide();
			}
		});
		btnTeacherLogin.setBounds(6, 6, 162, 67);
		frmLoginScreen.getContentPane().add(btnTeacherLogin);
		
		JButton btnStudentLogin = new JButton("Student Login");
		btnStudentLogin.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				StudentScreen sc=new StudentScreen();
				sc.StudentScreen();
				frmLoginScreen.hide();
			}
		});
		btnStudentLogin.setBounds(6, 85, 162, 67);
		frmLoginScreen.getContentPane().add(btnStudentLogin);
		
		JButton btnAdminLogin = new JButton("Admin Login");
		btnAdminLogin.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				AdminScreen as=new AdminScreen();
				as.AdminScreen();
				frmLoginScreen.hide();
			}
		});
		btnAdminLogin.setBounds(6, 164, 162, 67);
		frmLoginScreen.getContentPane().add(btnAdminLogin);
	}

}

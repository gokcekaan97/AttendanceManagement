import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;

public class AttendingScreen {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public void AttendingScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AttendingScreen window = new AttendingScreen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AttendingScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnAttend = new JButton("Attend");
		btnAttend.setBounds(86, 115, 117, 29);
		frame.getContentPane().add(btnAttend);
	}
}

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class AdminScreen {

	private JFrame frmStudentLoginScreen;
	private JTextField txtUsername;
	private JPasswordField pwdPassword;

	/**
	 * Launch the application.
	 */
	public void AdminScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminScreen window = new AdminScreen();
					window.frmStudentLoginScreen.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmStudentLoginScreen = new JFrame();
		frmStudentLoginScreen.setTitle("Admin Login Screen");
		frmStudentLoginScreen.setBounds(100, 100, 290, 140);
		frmStudentLoginScreen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmStudentLoginScreen.getContentPane().setLayout(null);
		
		txtUsername = new JTextField();
		txtUsername.setText("username");
		txtUsername.setBounds(135, 6, 130, 26);
		frmStudentLoginScreen.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		
		pwdPassword = new JPasswordField();
		pwdPassword.setText("password");
		pwdPassword.setBounds(135, 44, 130, 26);
		frmStudentLoginScreen.getContentPane().add(pwdPassword);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBounds(135, 83, 130, 29);
		frmStudentLoginScreen.getContentPane().add(btnLogin);
		
		JTextPane txtpnTeachersUsername = new JTextPane();
		txtpnTeachersUsername.setEditable(false);
		txtpnTeachersUsername.setText("Admin's username");
		txtpnTeachersUsername.setBounds(6, 11, 124, 16);
		frmStudentLoginScreen.getContentPane().add(txtpnTeachersUsername);
		
		JTextPane txtpnPassword = new JTextPane();
		txtpnPassword.setText("Password");
		txtpnPassword.setBounds(30, 50, 59, 16);
		frmStudentLoginScreen.getContentPane().add(txtpnPassword);
		
		JButton btnReturnBack = new JButton("Return back");
		btnReturnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui ls=new gui();
				ls.main(null);
				frmStudentLoginScreen.hide();
			}
		});
		btnReturnBack.setBounds(6, 83, 117, 29);
		frmStudentLoginScreen.getContentPane().add(btnReturnBack);
	}

}

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TeacherScreen {

	private JFrame frmTeacherLoginScreen;
	private JTextField txtUsername;
	private JPasswordField pwdPassword;

	/**
	 * Launch the application.
	 */
	public void TeacherScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TeacherScreen window = new TeacherScreen();
					window.frmTeacherLoginScreen.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TeacherScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmTeacherLoginScreen = new JFrame();
		frmTeacherLoginScreen.setTitle("Teacher Login Screen");
		frmTeacherLoginScreen.setBounds(100, 100, 290, 140);
		frmTeacherLoginScreen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmTeacherLoginScreen.getContentPane().setLayout(null);
		
		txtUsername = new JTextField();
		txtUsername.setText("username");
		txtUsername.setBounds(135, 6, 130, 26);
		frmTeacherLoginScreen.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		
		pwdPassword = new JPasswordField();
		pwdPassword.setText("password");
		pwdPassword.setBounds(135, 44, 130, 26);
		frmTeacherLoginScreen.getContentPane().add(pwdPassword);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBounds(135, 83, 130, 29);
		frmTeacherLoginScreen.getContentPane().add(btnLogin);
		
		JTextPane txtpnTeachersUsername = new JTextPane();
		txtpnTeachersUsername.setEditable(false);
		txtpnTeachersUsername.setText("Teacher's username");
		txtpnTeachersUsername.setBounds(6, 11, 124, 16);
		frmTeacherLoginScreen.getContentPane().add(txtpnTeachersUsername);
		
		JTextPane txtpnPassword = new JTextPane();
		txtpnPassword.setText("Password");
		txtpnPassword.setBounds(30, 50, 59, 16);
		frmTeacherLoginScreen.getContentPane().add(txtpnPassword);
		
		JButton btnReturnBack = new JButton("Return back");
		btnReturnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui ls=new gui();
				ls.main(null);
				frmTeacherLoginScreen.hide();
			}
		});
		btnReturnBack.setBounds(6, 83, 117, 29);
		frmTeacherLoginScreen.getContentPane().add(btnReturnBack);
	}
}
